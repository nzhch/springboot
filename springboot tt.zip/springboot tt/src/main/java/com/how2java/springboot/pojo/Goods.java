package com.how2java.springboot.pojo;

public class Goods {
	private long id;    
	private long goodsId;
	private String statDate;
	private String goodsName;
	private long goodsFavCnt;
	private long goodsUv;
	private long goodsPv;
	private long payOrdrCnt;
	private float goodsVcr;
	private long payOrdrGoodsQty;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public long getGoodsId() {
		return goodsId;
	}
	public void setGoodsId(long goodsId) {
		this.goodsId = goodsId;
	}
	public String getStatDate() {
		return statDate;
	}
	public void setStatDate(String statDate) {
		this.statDate = statDate;
	}
	public String getGoodsName() {
		return goodsName;
	}
	public void setGoodsName(String goodsName) {
		this.goodsName = goodsName;
	}
	public long getGoodsFavCnt() {
		return goodsFavCnt;
	}
	public void setGoodsFavCnt(long goodsFavCnt) {
		this.goodsFavCnt = goodsFavCnt;
	}
	public long getGoodsUv() {
		return goodsUv;
	}
	public void setGoodsUv(long goodsUv) {
		this.goodsUv = goodsUv;
	}
	public long getGoodsPv() {
		return goodsPv;
	}
	public void setGoodsPv(long goodsPv) {
		this.goodsPv = goodsPv;
	}
	public long getPayOrdrCnt() {
		return payOrdrCnt;
	}
	public void setPayOrdrCnt(long payOrdrCnt) {
		this.payOrdrCnt = payOrdrCnt;
	}
	public float getGoodsVcr() {
		return goodsVcr;
	}
	public void setGoodsVcr(float goodsVcr) {
		this.goodsVcr = goodsVcr;
	}
	public long getPayOrdrGoodsQty() {
		return payOrdrGoodsQty;
	}
	public void setPayOrdrGoodsQty(long payOrdrGoodsQty) {
		this.payOrdrGoodsQty = payOrdrGoodsQty;
	}
	
	
	
	

	
	
	
}
